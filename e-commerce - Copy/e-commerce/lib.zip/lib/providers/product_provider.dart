import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/product.dart';

class ProductProvider with ChangeNotifier {
  final List<Product> _products = [];

  List<Product> get products => [..._products];

  Product getById(String id) =>
      _products.firstWhere((product) => product.id == id);

  Future<void> addProduct(Product product) async {
    _products.add(product);
    notifyListeners();
    await _saveProductsToPrefs();
  }

  void removeProduct(String id) async {
    _products.removeWhere((product) => product.id == id);
    notifyListeners();
    await _saveProductsToPrefs();
  }

  Future<void> loadProducts() async {
    final prefs = await SharedPreferences.getInstance();
    final productData = prefs.getString('products');
    if (productData != null) {
      final List decoded = json.decode(productData);
      _products.clear();
      _products.addAll(decoded.map((e) => Product.fromMap(e)).toList());
      notifyListeners();
    }
  }

  Future<void> _saveProductsToPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    final productData = json.encode(_products.map((e) => e.toMap()).toList());
    await prefs.setString('products', productData);
  }
}
